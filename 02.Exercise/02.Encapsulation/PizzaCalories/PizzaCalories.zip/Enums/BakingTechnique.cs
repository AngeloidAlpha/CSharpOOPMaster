﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories.Enums
{
    // enum е възможноста да изпишем фиксирано множество от стойности които после ще обърнат 1 число
    public enum BakingTechnique
    {
        Crispy,
        Chewy,
        Homemade
    }
}
