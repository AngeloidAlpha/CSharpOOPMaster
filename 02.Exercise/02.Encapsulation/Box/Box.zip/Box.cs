﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Box
{
    public class Box
    {
        public Box(double length, double width, double height)
        {
            // условията за нулеви и негативни стойности
            if (length <= 0) throw new ArgumentException($"{nameof(Length)} cannot be zero or negative.");
            if (width <= 0) throw new ArgumentException($"{nameof(Width)} cannot be zero or negative.");
            if (height <= 0) throw new ArgumentException($"{nameof(Height)} cannot be zero or negative.");
            Length = length;
            Width = width;
            Height = height;
        }
        // създаваме параметрите ни
        public double Length { get; }
        public double Width { get; }
        public double Height { get; }
        public double SurfaceArea() => this.LateralSurfaceArea() + 2 * this.Length * this.Width;

        // пресмятане на лицето, всяка страна дължина по височина (и те са 3 такива еднакви страни които се дублират горе/долу)
        public double LateralSurfaceArea() => 2 * (this.Length * this.Height + this.Width * this.Height);
        public double Volume() => this.Length * this.Width * this.Height;
    }
}
